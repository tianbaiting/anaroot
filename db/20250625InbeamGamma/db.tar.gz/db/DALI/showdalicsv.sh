#
column -s, -t < DALI.csv |less -#2 -N -S
